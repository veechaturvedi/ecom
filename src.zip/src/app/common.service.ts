import {Injectable} from "@angular/core"


@Injectable()
export class CommonService{
    demo(){
        console.log("demo clicked");
    }
    productid
    products
    count = 0
}